package com.example.pertemuan11

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
